<template>
  <div class="analyse_box">
    <el-button plain
               @click="guanb">关闭</el-button>
    <div>
      对阵ID：
      <el-input v-model="scheduleID"
                placeholder="请输入内容"></el-input>
    </div>

    <div class="analyse_box1">
      <h2>本场比赛前（主、客队）重大新闻、信息提醒及临场信息提示与说明</h2>
      <dl class="analyse_box_header">
        <dd class="analyse_box_1 jc_a">序号</dd>
        <dd class="analyse_box_2 jz_a jc_a">新闻与信息内容</dd>
        <dd class="analyse_box_3">
          <div class="zk_biao jc_a">
            <span>主队</span>
            <span>客队</span>
          </div>
          <div class="jc_a"
               style="margin-left:10px">是或有（√）不是或没有（x）</div>
        </dd>
        <dd class="analyse_box_4 jz_a jc_a">具体说明（新闻与信息）</dd>
      </dl>
      <dl class="analyse_box_conter"
          v-for="(item,index) in tit_l"
          :key="index">
        <dd class="analyse_box_1">{{index+1}}</dd>
        <dd class="analyse_box_2">{{item.title}}</dd>
        <dd class="analyse_box_3 jz_a">
          <div class="span_div_x">
            <span class="span_x ">
              <el-radio v-model="item.isTrue"
                        :label="1">√</el-radio>
              <el-radio v-model="item.isTrue"
                        :label="2">×</el-radio>
              <el-radio v-model="item.isTrue"
                        :label="10">不选</el-radio>
            </span>

            <span class="">
              <el-radio v-model="item.radio"
                        :label="3">√</el-radio>
              <el-radio v-model="item.radio"
                        :label="4">×</el-radio>
              <el-radio v-model="item.radio"
                        :label="10">不选</el-radio>
            </span>

          </div>
        </dd>
        <dd class="analyse_box_4">
          <el-input v-model="item.conters"
                    placeholder="请输入内容"></el-input>
        </dd>
      </dl>
    </div>
    <div class="analyse_box2">
      <h2>本场比赛综合分析</h2>
      <div class="analyse_box2ss">
        <div class="zd_s">
          <div class="ylys">
            <h3 class="bcsm">主 队</h3>
            <div class="ylys1">
              <div>有 利 因 素</div>
              <ul>
                <li>
                  <el-input v-model="zhudui_list.ylYs.yl1"
                            placeholder="请输入内容"></el-input>
                </li>
                <li>
                  <el-input v-model="zhudui_list.ylYs.yl2"
                            placeholder="请输入内容"></el-input>
                </li>
                <li>
                  <el-input v-model="zhudui_list.ylYs.yl3"
                            placeholder="请输入内容"></el-input>
                </li>
              </ul>
            </div>
            <div class="ylys1">
              <div>不 利 因 素</div>
              <ul>
                <li>
                  <el-input v-model="zhudui_list.blYs.bl1"
                            placeholder="请输入内容"></el-input>
                </li>
                <li>
                  <el-input v-model="zhudui_list.blYs.bl2"
                            placeholder="请输入内容"></el-input>
                </li>
                <li>
                  <el-input v-model="zhudui_list.blYs.bl3"
                            placeholder="请输入内容"></el-input>
                </li>
              </ul>
            </div>
            <div class="bcsm">
              <p>
                <el-input v-model="zhudui_list.suoming"
                          placeholder="补充与重点说明:"></el-input>
              </p>
            </div>
            <div class="bcsm">
              <el-radio v-model="zhudui_list.bctj"
                        :label="1">1、正路</el-radio>
              <el-radio v-model="zhudui_list.bctj"
                        :label="2">2、防冷</el-radio>
              <el-radio v-model="zhudui_list.bctj"
                        :label="3">3、搏冷</el-radio>
              <el-radio v-model="zhudui_list.bctj"
                        :label="10">4、不选</el-radio>
            </div>
          </div>
        </div>

        <div class="zd_s">
          <div class="ylys">
            <h3 class="bcsm">客 队</h3>
            <div class="ylys1">
              <div>有 利 因 素</div>
              <ul>
                <li>
                  <el-input v-model="kedui_list.ylYs.yl1"
                            placeholder="请输入内容"></el-input>
                </li>
                <li>
                  <el-input v-model="kedui_list.ylYs.yl2"
                            placeholder="请输入内容"></el-input>
                </li>
                <li>
                  <el-input v-model="kedui_list.ylYs.yl3"
                            placeholder="请输入内容"></el-input>
                </li>
              </ul>
            </div>
            <div class="ylys1">
              <div>不 利 因 素</div>
              <ul>
                <li>
                  <el-input v-model="kedui_list.blYs.bl1"
                            placeholder="请输入内容"></el-input>
                </li>
                <li>
                  <el-input v-model="kedui_list.blYs.bl2"
                            placeholder="请输入内容"></el-input>
                </li>
                <li>
                  <el-input v-model="kedui_list.blYs.bl3"
                            placeholder="请输入内容"></el-input>
                </li>
              </ul>
            </div>
            <div class="bcsm">
              <p>
                <el-input v-model="kedui_list.suoming"
                          placeholder="补充与重点说明:"></el-input>
              </p>
              <div></div>
            </div>
            <div class="bcsm">
              <p>
                <el-input v-model="kedui_list.zztj"
                          placeholder="最终推荐：:"></el-input>
              </p>
            </div>
          </div>
        </div>

      </div>
    </div>
    <el-button class="bun_ss"
               v-if="isxg"
               @click="xiugai"
               type="success">修改</el-button>
    <el-button class="bun_ss"
               v-else
               @click="tijiao"
               type="success">创建</el-button>
  </div>
</template>
<script >
import Qs from 'qs'
export default {
  props: ['id_sss'],
  data () {
    return {
      tit_l: [
        {
          title: '俱乐部成立纪念日或重大事件纪念日及近期重大活动',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '俱乐部高层生日、主教练生日或关键球员生日；高层与球员动态新闻',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '主教练由于战绩因素是否存在下课风险',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '新上任主教练对球队是否在磨合期，开门红或先不输球情况',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '主教练与俱乐部高层及球员间是否有不利于团结的事件',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '是否德比（城市德比、地区德比、国家德比）及火爆与仇恨程度',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '主力阵容球员伤停或红黄牌停赛或主教练被罚出场',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '主力球员复出（判断是受伤复出还是正常停赛复出）对比赛的影响',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '是否为临近杯赛留力，存在保平不输或遇关系球队送分的心态',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '是否有重视周中杯赛，在周末联赛中轮换阵容输球爆冷的可能',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '关系球队送分-保级无忧而不想进进欧战区给需分的关系球队送分',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '是否有为上轮或上赛季（大比分输球）的复仇雪耻之战的可能',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '主教练间关系与战绩因素，同乡、师徒、好友或战绩一边倒等',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '俱乐部间是否存在派系因素，嫡系、打手、小弟，权衡胜负走势',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '是否存在主场龙、客场虫、平局大师情况或反之',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '球队高层、主教练或主要球员的不当言行等对裁判或足联的影响',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '球迷闹事后遗症或球场内外其他重大事件后遗症',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '空场比赛、中立场地比赛、惩罚性的不让主队或客队球迷入场',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '球队近期整体状态是平稳期、丢分萎靡期低谷期、高歌猛进拿分期',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '由于两队比赛间隙时间的不同，是否存在体力充沛或透支输球可能',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '俱乐部股权变更、高层重大人事变动等因素',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '更衣室事件',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '新赛季开始与冬歇期结束后，新引进球员对阵型的调整和磨合因素',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '转会结束后，判断球队是加强了阵容还是削弱了实力（为交易挣钱）',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '新冠病毒对球队及对本场比赛的影响',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '主力球员训练中受伤、生病或场外事件影响而不能出场',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '恶劣天气、恐怖事件影响',
          conters: '',
          radio: 10,
          isTrue: 10
        }, {
          title: '其它',
          conters: '',
          radio: 10,
          isTrue: 10
        }
      ],
      zhudui_list: {
        ylYs: { yl1: '', yl2: '', yl3: '' },
        blYs: { bl1: '', bl2: '', bl3: '' },
        suoming: '',
        bctj: 1
      },
      kedui_list: {
        ylYs: { yl1: '', yl2: '', yl3: '' },
        blYs: { bl1: '', bl2: '', bl3: '' },
        suoming: '',
        zztj: ''
      },
      scheduleID: '',
      isxg: false,
      id_ss: ''


    }
  },
  created () {
    // this.tit_l.forEach((item, i) => {
    //   item[`conters${i + 1}`] = ''
    // })
    this.get_li()
  },
  methods: {
    guanb () {
      this.scheduleID = ''
      this.$emit('fromChild', false)
    },
    async get_li () {
      const { data: res } = await this.$http.get(`/fenxi_table/${this.id_sss}`)
      this.scheduleID = res.data.scheduleID
      this.content_ss = res.data.content
      this.id_ss = res.data.id
      if (res.data.content) {
        this.isxg = true;
        let obj = JSON.parse(res.data.content)
        this.tit_l = obj.tit_l
        this.zhudui_list = obj.zhudui_list
        this.kedui_list = obj.kedui_list
      } else {
        this.isxg = false
      }
    },
    async tijiao () {
      let list = {
        tit_l: this.tit_l,
        zhudui_list: this.zhudui_list,
        kedui_list: this.kedui_list
      }
      var formData = Qs.stringify({ content: JSON.stringify(list), scheduleID: this.scheduleID });
      const { data: player } = await this.$http.post(`/fenxi_table`, formData)
    },
    async xiugai () {
      let list = {
        tit_l: this.tit_l,
        zhudui_list: this.zhudui_list,
        kedui_list: this.kedui_list
      }
      var formData = Qs.stringify({ content: JSON.stringify(list), scheduleID: this.scheduleID });
      const { data: player } = await this.$http.put(`/fenxi_table/${this.id_ss}`, formData)
    }

  }

}
</script>
<style  scoped>
.analyse_box {
  width: 1200px;
  margin: 30px 0;
  margin-left: 50%;
  transform: translateX(-50%);
  overflow: hidden;
}
.analyse_box1,
.analyse_box2 {
  border: 6px solid;
}

h2 {
  text-align: center;
}
.analyse_box dl {
  display: flex;
}
/* .analyse_box {
  border: 1px solid;
} */
.analyse_box_conter dd,
.analyse_box_header dd {
  border: 1px solid;
  font-size: 14px;
}
.analyse_box_1 {
  width: 40px;
  display: flex;
  justify-content: center;
  align-items: center;
}
.analyse_box_2 {
  width: 420px;
  display: flex;
  align-items: center;
}
.analyse_box_3 {
  width: 200px;
}
.analyse_box_4 {
  width: 532px;
  display: flex;
  align-items: center;
}
.zk_biao {
  width: 100%;
  border-bottom: 1px solid;
  text-align: center;
}
.jz_a {
  display: flex;
  justify-content: center;
  align-items: center;
}
.jc_a {
  font-weight: 900;
}
/* -------------------------------- */
.analyse_box2ss {
  display: flex;
  width: 100%;
}
.zd_s {
  width: 50%;
}
.ylys h3 {
  text-align: center;
}
.ylys1 {
  display: flex;
}
.ylys1 div {
  width: 10%;
  border: 1px solid;
  -webkit-writing-mode: vertical-rl;
  writing-mode: vertical-rl;
  display: flex;
  justify-content: center;
  align-items: center;
}
.ylys1 ul {
  width: 90%;
}
li {
  height: 50px;
  border: 1px solid;
}
.bcsm {
  height: 50px;
  border: 1px solid;
  line-height: 50px;
}

.span_div_x {
  display: flex;
}
.span_x {
  border-right: 2px solid;
}
.xxx {
  display: flex;
  justify-content: space-around;
  width: 80%;
}
.bun_ss {
  float: right;
}
.analyse_box2 li {
  width: 100%;
}
.analyse_box2 li input {
  width: 100%;
}
.el-input {
  width: 90% !important;
}
</style>
