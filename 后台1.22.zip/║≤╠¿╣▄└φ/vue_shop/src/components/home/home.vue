<template>
  <el-container class="home_box">
    <!-- 头部 -->
    <el-header>
      <div>
        <img src="../../assets/logo.png" />
        <span>管理系统</span>
      </div>
      <el-button @click="logout"
                 type="info">退出</el-button>
    </el-header>
    <!-- 主体 -->
    <el-container>
      <!-- 侧边导航 -->
      <el-aside :width="isCollapse ? '64px':'200px'">
        <div class="toddle-button"
             @click="toggleChange">|||</div>
        <!-- 侧边栏 -->
        <el-menu :unique-opened="true"
                 background-color="#333744"
                 text-color="#fff"
                 active-text-color="#409EFF"
                 :collapse="isCollapse"
                 :collapse-transition="false"
                 :router="true"
                 :default-active="activePath">
          <!-- 一级菜单 -->
          <el-menu-item :index="item.table_name_e"
                        @click="saveNavState(item.table_name_e)"
                        v-for="(item,key) in menulist"
                        :key="key">
            <i :class="iconsObj[3]"></i>
            <span>{{item.table_name_j}}</span>
          </el-menu-item>

        </el-menu>
      </el-aside>
      <!-- 内容 -->
      <el-main>
        <!-- 路由占位符 -->
        <router-view></router-view>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
export default {
  name: 'home',
  created () {
    // console.log(this.$router.options.routes)
    this.activePath = this.$route.path.slice(1)
    this.getMenuList()
  },
  data () {
    return {
      // activeDate: new Date(),
      // 导航列表
      menulist: [],
      // 是否水平折叠收起菜单
      isCollapse: false,
      // 被激活链接地址
      activePath: '',
      iconsObj: {
        '3': 'el-icon-s-order',
      }
    }
  },

  methods: {
    // 退出
    logout () {
      window.sessionStorage.clear()
      this.$router.push('/login')
    },
    // |||
    toggleChange () {
      this.isCollapse = !this.isCollapse;
    },
    // 菜单
    saveNavState (activePath) {
      this.activePath = activePath
      // console.log(activePath)
    },
    // 获取侧边导航列表
    async getMenuList () {
      const { data: res } = await this.$http.get('/table')
      res.push({ table_name_e: "/fenxi_table", table_name_j: "赛前分析表" })
      this.menulist = res
      // console.log(this.menulist)
    }
  }
}
</script>
<style scoped>
.el-header {
  background-color: #373d41;
  display: flex;
  justify-content: space-between;
  padding-left: 0;
  align-items: center;
  color: #fff;
  font-size: 20px;
}
.el-header > div {
  width: 200px;
  display: flex;
  justify-content: center;
  align-items: center;
}
.el-header > div > span {
  padding-left: 10px;
}
.el-header > div > img {
  width: 50px;
  height: 50px;
  border-radius: 50%;
}
.el-aside {
  background-color: #333744;
}
.el-menu {
  border-right: none;
}
.el-main {
  background-color: #eaedf1;
}
.home_box {
  height: 100%;
  overflow: hidden;
}
.home_box i {
  margin-right: 6px;
}
.toddle-button {
  background-color: #4a5064;
  font-size: 10px;
  line-height: 24px;
  color: #fff;
  text-align: center;
  letter-spacing: 0.2em;
  cursor: pointer;
}
</style>

