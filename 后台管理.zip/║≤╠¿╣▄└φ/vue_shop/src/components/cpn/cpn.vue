<template>
  <div class="player_box">
    <!-- 卡片 -->
    <el-card class="box-card">
      <!-- 搜索与添加 -->
      <el-row :gutter="20">
        <el-col :span="7">
          <el-input placeholder="请输入内容"
                    v-model="queryInfo.keyword"
                    clearable
                    @clear="usersList">
            <el-button slot="append"
                       icon="el-icon-search"
                       @click="usersList"></el-button>
          </el-input>
        </el-col>
        <el-col :span="4">
          <el-button type="primary"
                     @click="dialogVisible = true">添加信息</el-button>
        </el-col>
      </el-row>
    </el-card>
    <!-- 内容 -->
    <el-table height='510'
              :data="PlayerData"
              border
              size="mini"
              :header-cell-style="{
    'color': '#fff',
       'background-color': 'rgb(99 112 128)',
    'font-size':'14px'
}"
              style="width: 100%">
      <el-table-column :label="tableData.table_name"
                       align="center">
        <el-table-column :label="item.name_j"
                         align="center"
                         :width="item.width"
                         v-for="(item,index) in tableData.columns"
                         :key="index">
          <template slot-scope='scope'>
            <span>{{scope.row[item.name_e]}}</span>
          </template>
        </el-table-column>
        <el-table-column label="操作"
                         align="center">
          <template slot-scope="scope">
            <el-tooltip :enterable="false"
                        effect="dark"
                        content="修改"
                        placement="top-start">
              <el-button type="primary"
                         size="mini"
                         icon="el-icon-edit"
                         @click="showEditDialog(scope.row[tableData.primary_key])"></el-button>
            </el-tooltip>
            <el-tooltip :enterable="false"
                        effect="dark"
                        content="删除"
                        placement="top-start">
              <el-button type="danger"
                         size="mini"
                         icon="el-icon-delete"
                         @click="removeUserById(scope.row[tableData.primary_key])"></el-button>
            </el-tooltip>
          </template>
        </el-table-column>
      </el-table-column>

    </el-table>
    <!-- 分页 -->
    <el-pagination @size-change="handleSizeChange"
                   @current-change="handleCurrentChange"
                   :page-size="50"
                   layout="total,prev, pager, next,jumper"
                   :total="max_page*50">
    </el-pagination>

    <!-- 添加用户对话框 -->
    <el-dialog title="添加信息"
               :visible.sync="dialogVisible"
               width="50%"
               @close="addDialogClosed">
      <!-- 内容主题区 -->
      <span>
        <el-form ref="ruleFormref"
                 label-width="120px">
          <el-form-item :label="item.name_j"
                        v-for="(item,index) in ruleForms"
                        :key="index">
            <el-input :disabled="!item.is_edit"
                      v-model="item[item.name_e]">
              <el-select v-model="item[item.name_e]"
                         v-if="item.choice_field"
                         slot="prepend"
                         placeholder="请选择">
                <el-option v-for="(i,k) in item.choice_field"
                           :key="k"
                           :label="i"
                           :value="k"></el-option>
              </el-select>
            </el-input>
          </el-form-item>
        </el-form>
      </span>
      <!-- 底部区 -->
      <span slot="footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary"
                   @click="addUser">确 定</el-button>
      </span>
    </el-dialog>

    <!-- 修改用户对话框 -->
    <el-dialog title="修改信息"
               :visible.sync="editDialogVisible"
               width="50%"
               @close="editFormClosed">
      <span>
        <el-form ref="editFormref"
                 label-width="120px">
          <el-form-item :label="item.name_j"
                        v-for="(item,index) in editForm"
                        :key="index">
            <el-input v-model="item[item.name_e]"
                      :disabled="!item.is_edit">
              <el-select v-model="item[item.name_e]"
                         v-if="item.choice_field"
                         slot="prepend"
                         placeholder="请选择">
                <el-option v-for="(i,k) in item.choice_field"
                           :key="k"
                           :label="i"
                           :value="k"></el-option>
              </el-select>
            </el-input>
          </el-form-item>
        </el-form>
      </span>
      <span slot="footer">
        <el-button @click="editDialogVisible = false">取 消</el-button>
        <el-button type="primary"
                   @click="editFormUser">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import Qs from 'qs'
export default {
  name: 'home',
  created () {
    this.sty = this.$route.path
    this.getPlayer()
  },
  watch: {
    $route (to, from) {
      // 对路由变化作出响应...
      // console.log(to.path != from.path)
      if (to.path != from.path) {
        this.sty = this.$route.path
        this.getPlayer()
      }
    }
  },
  data () {
    return {
      select1: '',
      PlayerData: [],
      tableData: [],
      sty: '',
      max_page: 1,
      queryInfo: {
        page: 1,
        keyword: '',
      },
      //   添加用户表单数据
      ruleForms: [],
      //   控制添加用户显示与隐藏
      dialogVisible: false,
      // 修改表单数据
      editForm: [],
      editDialogVisible: false,
    }
  },
  methods: {
    async getPlayer () {
      this.queryInfo.page = 1
      this.queryInfo.keyword = ''
      const { data: player } = await this.$http.get(this.sty, { params: this.queryInfo })
      const { data: table } = await this.$http.get(`table${this.sty}`)
      this.PlayerData = player.data
      // 添加栏目表头
      this.ruleForms = []
      this.editForm = []
      table.columns.forEach(item => {
        item[item.name_e] = ''
        let newData = JSON.parse(JSON.stringify(item))
        this.ruleForms.push(newData)
      })
      table.columns.forEach(item => {
        item[item.name_e] = ''
        let newData = JSON.parse(JSON.stringify(item))
        this.editForm.push(newData)
      })
      this.tableData = table
      this.max_page = player.max_page
    },
    // 监听添加用户对话框关闭事件
    addDialogClosed () {
      // this.dialogVisible = false
      this.ruleForms.forEach(item => {
        item[item.name_e] = ''
      })
    },
    // 监听修改对话框关闭状态
    editFormClosed () {
      this.$refs.editFormref.resetFields()
    },
    // 添加
    async addUser (v) {
      // 添加用户表单数据
      let ruleForms = {}, isTrue = false
      this.ruleForms.forEach((item, i) => {
        ruleForms[item.name_e] = item[item.name_e]
        if (ruleForms[item.name_e]) {
          isTrue = true
        }
      })
      if (!isTrue) return this.$message.error('至少填一个数据')
      var formData = Qs.stringify(ruleForms);
      // const { data: res } = await this.$http.request({
      //   url: '/player',
      //   method: 'POST',
      //   data: formData,
      //   headers: {
      //     'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
      //   }
      // })
      // console.log(this.$route.path)
      const { data: res } = await this.$http.post(this.$route.path, formData)
      if (res.code !== 1) return this.$message.error(res.msg)
      this.$message.success(res.msg)
      //  隐藏对话框
      this.dialogVisible = false;
      // 重新获取数据
      this.getPlayer()
    },

    // 修改
    async showEditDialog (id) {
      const { data: res } = await this.$http.get(`${this.sty}/` + id)
      //   添加用户表单数据
      this.editForm.forEach((item, i) => {
        item[item.name_e] = res[item.name_e]
      })
      this.editDialogVisible = true
    },
    // 监听修改对话框关闭状态
    editFormClosed () {
      this.$refs.editFormref.resetFields()
    },
    // 点击修改确定按钮
    async editFormUser () {
      let editForm = {}
      this.editForm.forEach((item, i) => {
        editForm[item.name_e] = item[item.name_e]
      })
      var formData = Qs.stringify(editForm);
      //    发起修改用户信息的数据请求
      const { data: res } = await this.$http.put(`${this.sty}/` + editForm.PlayerID, formData)
      if (res.code !== 1) {
        this.$message.error('更新数据失败')
      }
      //   关闭对话框
      this.editDialogVisible = false
      // 刷新数据列表
      this.getPlayer()
      // 提示修改成功
      this.$message.success(res.msg)
    },
    // 删除
    async removeUserById (id) {
      const confirmRes = await this.$confirm('此操作将永久删除该数据, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).catch(err => err)
      // 如果用去确定返回confirm,如果取消返回cancel
      if (confirmRes !== 'confirm') {
        return this.$message.info('已取消删除')
      }
      const { data: res } = await this.$http.delete(`${this.sty}/` + id)
      // console.log(res)
      if (res.code != 1) {
        return this.$message.error(res.msg)
      }
      this.$message.success(res.msg)
      this.getPlayer()
    },
    // 搜索
    usersList (v) {
      this.queryInfo.page = 1
      this.getPlayer()
    },
    // 分页
    handleSizeChange (v) {
      this.queryInfo.page = v
      this.getPlayer()
    },
    handleCurrentChange (v) {
      this.queryInfo.page = v
      this.getPlayer()
    }
  }
}
</script>
<style scoped>
.player_box {
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.el-pagination {
  margin: 10px auto;
}
.el-select {
  width: 200px;
}
</style>

