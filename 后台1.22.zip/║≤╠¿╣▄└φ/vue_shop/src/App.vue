<template>
  <div id="app">
    <!-- {{$store.state}} -->

    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
</style>