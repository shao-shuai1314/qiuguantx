module.exports = {

    publicPath: './',
    
    }