<template>
  <div class="player_box">
    <!-- 卡片 -->
    <el-card class="box-card">
      <!-- 搜索与添加 -->
      <el-row :gutter="20">
        <el-col :span="7">
          <el-input placeholder="请输入内容"
                    v-model="queryInfo.keyword"
                    clearable
                    @change="usersList"
                    @clear="usersList">
            <el-button slot="append"
                       icon="el-icon-search"
                       @click="usersList"></el-button>
          </el-input>
        </el-col>
        <el-col :span="4">
          <el-button type="primary"
                     @click="addUser">添加信息</el-button>
        </el-col>
      </el-row>
    </el-card>
    <!-- 内容 -->
    <el-table height='510'
              :data="list_s"
              border
              size="mini"
              :header-cell-style="{
    'color': '#fff',
       'background-color': 'rgb(99 112 128)',
    'font-size':'14px'
}"
              style="width: 100%">
      <el-table-column label="赛前分析表"
                       align="center">
        <el-table-column prop="matchtime"
                         align="center"
                         label="比赛日期"
                         width="">
        </el-table-column>
        <el-table-column prop="matchinfo"
                         label="对阵球队"
                         align="center"
                         width="">
        </el-table-column>
        <el-table-column prop="scheduleID"
                         align="center"
                         label="对阵ID"
                         width="">
          <template slot-scope="scope">
            <el-button size="mini"
                       @click="addID(scope.row.id)">{{scope.row.scheduleID}}</el-button>
          </template>
        </el-table-column>
        <el-table-column prop="username"
                         align="center"
                         label="用户"
                         width="">
        </el-table-column>
        <!-- <el-tooltip :enterable="false"
                        effect="dark"
                        content="删除"
                        placement="top-start">
              <el-button type="danger"
                         size="mini"
                         icon="el-icon-delete"
                         @click="removeUserById(scope.row[tableData.primary_key])"></el-button>
            </el-tooltip> -->
        <!-- </el-table-column> -->
        <el-table-column label="操作"
                         align="center">
          <template slot-scope="scope">
            <el-tooltip :enterable="false"
                        effect="dark"
                        content="删除"
                        placement="top-start">
              <el-button type="danger"
                         size="mini"
                         icon="el-icon-delete"
                         @click="removeUserById(scope.row.id)"></el-button>
            </el-tooltip>
          </template>
        </el-table-column>
      </el-table-column>

    </el-table>
    <!-- 分页 -->
    <el-pagination @size-change="handleSizeChange"
                   @current-change="handleCurrentChange"
                   :page-size="50"
                   layout="total,prev, pager, next,jumper"
                   :total="max_page*50">
    </el-pagination>

    <!-- 弹框 -->
    <div class="tankuan"
         v-if="guanb_s">
      <!-- <el-button plain
                 @click="guanb">关闭</el-button> -->
      <Analyse @fromChild="getChild"
               :id_sss="id_ss"></Analyse>
    </div>

  </div>
</template>
<script>
import Qs from 'qs'
import Analyse from './analyse';
export default {
  components: {
    Analyse
  },
  name: 'home',
  created () {
    this.sty = this.$route.path
    this.getPlayer()
  },
  watch: {
    // $route (to, from) {
    //   // 对路由变化作出响应...
    //   // console.log(to.path != from.path)
    //   if (to.path != from.path) {
    //     this.sty = this.$route.path
    //     this.queryInfo.keyword = ''
    //     this.queryInfo.page = 1
    //     this.getPlayer()
    //   }
    // }
  },
  data () {
    return {
      select1: '',
      PlayerData: [],
      tableData: [],
      sty: '',
      max_page: 1,
      queryInfo: {
        page: 1,
        keyword: '',
      },
      //   添加用户表单数据
      ruleForms: [],
      //   控制添加用户显示与隐藏
      dialogVisible: false,
      // 修改表单数据
      editForm: [],
      editDialogVisible: false,
      list_s: [],
      guanb_s: false,
      id_ss: '',

      matchinfo: '',
      scheduleID: '',
      username: '',
      userID: '',
    }
  },
  methods: {
    async getPlayer () {
      // this.queryInfo.keyword = ''
      const { data: res } = await this.$http.get(`${this.sty}`, { params: this.queryInfo })
      this.list_s = res.data
      this.max_page = res.max_page
      // console.log(this.list_s)
    },

    // 删除
    async removeUserById (id) {
      // console.log(id)
      const confirmRes = await this.$confirm('此操作将永久删除该数据, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).catch(err => err)
      // 如果用去确定返回confirm,如果取消返回cancel
      if (confirmRes !== 'confirm') {
        return this.$message.info('已取消删除')
      }
      const { data: res } = await this.$http.delete(`${this.sty}/` + id)
      // console.log(res)
      if (res.code != 1) {
        return this.$message.error(res.msg)
      }
      this.$message.success(res.msg)
      this.getPlayer()
    },
    addID (id) {
      this.guanb_s = true
      this.id_ss = id
    },
    // 搜索
    usersList (v) {
      this.queryInfo.page = 1
      this.getPlayer()
    },
    // 分页
    handleSizeChange (v) {
      this.queryInfo.page = v
      this.getPlayer()
    },
    handleCurrentChange (v) {
      this.queryInfo.page = v
      this.getPlayer()
    },
    getChild (v) {
      this.guanb_s = v
    },
    // 添加
    addUser () {
      this.id_ss = ''
      this.guanb_s = true
    },

  }
}
</script>
<style scoped>
.player_box {
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.el-pagination {
  margin: 10px auto;
}
.el-select {
  width: 200px;
}
.tankuan {
  width: 100%;

  height: 100%;
  position: absolute;
  background: #fff;
  top: 60px;
  left: 0;
  z-index: 999999999;
}
</style>

