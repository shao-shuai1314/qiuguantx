import Vue from 'vue'
import VueRouter from 'vue-router'
import axios from 'axios'

const cpn = () => import( /* webpackChunkName: "login_home_welcome" */ '@/components/cpn/cpn')
const cpns = () => import( /* webpackChunkName: "login_home_welcome" */ '@/components/cpn/cpns')
const login = () => import( /* webpackChunkName: "login_home_welcome" */ '@/components/login/login')
const home = () => import( /* webpackChunkName: "login_home_welcome" */ '@/components/home/home')
const welcome = () => import( /* webpackChunkName: "login_home_welcome" */ '@/components/home/welcome')

Vue.use(VueRouter)
const routes = [{
    path: "/",
    redirect: '/login'
  },
  {
    path: '/login',
    name: 'login',
    component: login
  },
  {
    path: '/home',
    name: 'home',
    component: home,
    redirect: "/welcome",
    children: [{
      path: '/welcome',
      component: welcome
    }, {
      path: '/fenxi_table',
      name: 'cpns',
      component: cpns
    }]
  }
]
const router = new VueRouter({
  // mode: 'history',
  routes
})


let newRoutes = true
router.beforeEach((to, from, next) => {
  let token = window.localStorage.getItem('token')
  //  判断是否登录页面
  if (to.path != '/login' && newRoutes) {
    newRoutes = false
    // 是否有token
    if (token) {
      // 刷新动态路由消失
      // 调用Api获取动态路由
      axios.get('/table').then(res => {
        res.data.forEach(element => {
          //   // 重要：赋值变量
          element.path = `/${element.table_name_e}`
          let val = '/cpn/cpn'
          element.component = function component(resolve) {
            require(["@/components" + val], resolve)
          };
        });
        router.options.routes[2].children = res.data;
        // 添加路由数据
        routes.splice(1, 1);
        delete routes[1].name
        router.addRoutes(router.options.routes);
        // console.log(routes_s)
        next(to.path)
      })
    } else {
      next('/login')
    }
  } else {
    next()
  }
})

export default router